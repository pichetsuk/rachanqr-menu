<?php
return [
    "all" => "الكل",
    "columns" => "أعمدة",
    "hide_show_pagination" => "عرض/إخفاء أرقام الصفحات",
    "loading" => "جارى التحميل، برجاء الإنتظار ...",
    "page_from_to" => "عرض {0} إلى {1} من {2} صفوف",
    "refresh" => "إعادة تحميل",
    "rows_per_page" => "{0} صف بالصفحة",
    "toggle" => "تغيير",
];
