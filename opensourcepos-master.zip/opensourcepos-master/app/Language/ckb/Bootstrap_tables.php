<?php
return [
    "all" => "",
    "columns" => "",
    "hide_show_pagination" => "",
    "loading" => "",
    "page_from_to" => "",
    "refresh" => "",
    "rows_per_page" => "",
    "toggle" => "",
];
