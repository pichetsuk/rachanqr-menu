<?php
return [
    "half_down" => "Yarım aşağı",
    "half_even" => "Yarım hətta",
    "half_five" => "Yarısı",
    "half_odd" => "Yarım təkliklərdə",
    "half_up" => "Yarım yuxarı",
    "round_down" => "Yuvarla aşağı",
    "round_up" => "Yuvarla yuxarı",
];
